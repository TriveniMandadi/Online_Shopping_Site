﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingEntityLib
{
    /// <summary>
    /// Product Details class
    /// </summary>
    public class ProductDetails
    {
        /// <summary>
        /// Product Id
        /// </summary>
        public int Pid { get; set; } 
        
        /// <summary>
        /// Product Name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Picture (Image of product)
        /// </summary>
        public string Picture { get; set; }

        /// <summary>
        /// Price (Price of product)
        /// </summary>
        public int Price { get; set; }

        /// <summary>
        /// Content (Description or details of the product)
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// This method is used for displaying the description of products.
        /// so that every column value will be in each row. This will happen using split operator
        /// </summary>
        /// <returns></returns>
        public string Display()
        {
            //initialising data variable with empty string 
            string data = "";
            //Splitting the content using ',' and storing in columns variable of string(arrays) type
            string[] columns = Content.Split(',');
            //This loop stores the values present in columns into column variable of same type    
            foreach (var column in columns)
            {
                //declaring two variables of string type
                string columnName, columnValue;
                //The data in Column variable is splitted by : and storing in an array
                string[] columnNameValue = column.Split(':');
                //0th index value of columnvalue is stored in columnname
                columnName = columnNameValue[0];
                //1st index value of columnvalue is stored in columnname
                columnValue = columnNameValue[1];
                //concatenating the result with data variable
                data = data + columnName + ": " + columnValue + "<br/>";
            }
            //returns the content stored in data
            return data;
        }
    }
}

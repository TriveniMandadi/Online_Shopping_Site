﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingEntityLib
{
    /// <summary>
    /// Cart Items class 
    /// </summary>
    public class CartItems
    {
        /// <summary>
        /// product id
        /// </summary>
        public int Pid { get; set; }

        /// <summary>
       /// product name
       /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// picture (Image of product)
        /// </summary>
        public string Picture { get; set; }

        /// <summary>
        /// Quantity(Number of items)
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// price (price of product)
        /// </summary>
        public int Price { get; set; }     
    }
}

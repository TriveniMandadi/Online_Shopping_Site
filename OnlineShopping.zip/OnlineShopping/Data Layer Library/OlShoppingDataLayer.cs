﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;     //For ADO.NET classes sqlconnection,sqlcommand
using OnlineShoppingEntityLib;   // For entities in OnlineShoppingEntityLib
using OnlineShoppingExceptionLib;//For user defined exception library
using System.Configuration;      //for reading configurations from App.Config file

namespace OnlineShoppingDataAccessLayerLib
{
    /// <summary>
    /// This class extends the methods defined in online shopping datalayer interface
    /// </summary>
    public class OlShoppingDataLayer : IOnlineShpngDataLayer
    {
        SqlConnection con; // sql connection
        SqlCommand cmd;  // sql command
        /// <summary>
        /// constructor for olshoppingdatalayer
        /// </summary>
        public OlShoppingDataLayer()
        {
            con = new SqlConnection(); //configure connection object
            con.ConnectionString = ConfigurationManager.ConnectionStrings["sqlconstr"].ConnectionString;
        }

        /// <summary>
        /// This method will display/retrieve all the categories in the home page 
        /// </summary>
        /// <returns>List of categories from database</returns>
        public List<Home> GetAllCategoriesList()
        {
            //creates object of type list for home entity class 
            List<Home> categoryList = new List<Home>();
            //try block incase if code throws an exception
            try
            {
                //configuring command for SELECT statement
                cmd = new SqlCommand();
                //Query for SELECTing all the columns from ol_category table in database
                cmd.CommandText = "select * from ol_category";                
                cmd.CommandType = CommandType.Text;
                //attach the connection with the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //executes the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    Home h = new Home
                    {
                        CategoryId = (int)sdr[0],
                        CategoryName = sdr[1].ToString()
                    };
                    //adding to categoryList
                    categoryList.Add(h);
                }
                //closing of sdr connection
                sdr.Close();
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException sqlException)
            {
                //if sql exception occurs , it will be thrown
                throw new OnlineShoppingException(sqlException.Message);
            }
            //If any other exception occurs other than sqlexception,here they will be handled
            catch (Exception exception)
            {
                //If any exception occurs other than sql, it will throw here
                throw new OnlineShoppingException(exception.Message);
            }
            // The finally block executes whether exception rise or not and whether exception handled or not
            finally
            {
                //closing the connection
                con.Close();
            }
            //returns list of categories
            return categoryList;
        }

        /// <summary>
        /// This method will retrieve the products present in category when clicked on categoryname
        /// </summary>
        /// <param name="categoryName">Names of categories are passed</param>
        /// <returns>It returns the products list present in selected category</returns>
        public List<Products> GetProductsByCategory(string CategoryName)
        {
            // creates object of type list for Products entity class
            List<Products> productsList = new List<Products>();
            //try block incase if code throws an exception
            try
            {
                //configuring command for SELECT statement
                cmd = new SqlCommand();
                //Join Query for SELECTing columns from ol_category and ol_product tables in database
                cmd.CommandText = "select p.pid,p.pname,p.picture,p.price from ol_product as p join" +
                                   " ol_category as c on p.cid=c.cid and c.cname like @cn";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@cn", "%" + CategoryName + "%");
                //specify the type of command
                cmd.CommandType = CommandType.Text;
                //attach connection to the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //executes the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    Products products = new Products
                    {
                        Pid = (int)sdr[0],
                        ProductName = sdr[1].ToString(),
                        Picture = sdr[2].ToString(),                        
                        Price = (int)sdr[3]
                    };
                    productsList.Add(products);
                }
                //closing sdr connection
                sdr.Close();
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException sqlException)
            {
                //if sql exception occurs , it will be thrown
                throw new OnlineShoppingException(sqlException.Message);
            }
            //If any other exception occurs other than sqlexception,here they will be handled
            catch (Exception exception)
            {
                //If any exception occurs other than sql, it will throw here
                throw new OnlineShoppingException(exception.Message);
            }
            // The finally block executes whether exception rise or not and whether exception handled or not
            finally
            {
                //closing the connection
                con.Close();
            }
            //returns list of products
            return productsList;
        }

        /// <summary>
        /// This method will retrieve the products based on the name of the product given by user
        /// </summary>
        /// <param name="productName">Names of products are passed</param>
        /// <returns>returns the products with the searched product</returns>
        public List<Products> GetProductsByProductName(string productName)
        {
            // creates object of type list for Products entity class
            List<Products> productsList = new List<Products>();
            //try block incase if code throws an exception
            try
            {
                //configuring command for SELECT statement
                cmd = new SqlCommand();
                //Join Query for SELECTing columns from ol_category and ol_product tables in database
                cmd.CommandText = "select p.pid,p.pname,p.picture,p.price from ol_product as p join" +
                                   " ol_category as c on p.cid=c.cid and p.pname like @cn";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@cn", "%" + productName + "%");
                //Specify the type of command
                cmd.CommandType = CommandType.Text;
                //attach connection to the command
                cmd.Connection = con;
                //Open the connection
                con.Open();
                //Executes the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    Products products = new Products
                    {
                        Pid = (int)sdr[0],
                        ProductName = sdr[1].ToString(),
                        Picture = sdr[2].ToString(),                        
                        Price = (int)sdr[3]
                    };
                    //Adds products 
                    productsList.Add(products);
                }
                //close the sdr connection
                sdr.Close();
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException sqlException)
            {
                //if sql exception occurs , it will be thrown
                throw new OnlineShoppingException(sqlException.Message);
            }
            //If any other exception occurs other than sqlexception,here they will be handled
            catch (Exception exception)
            {
                //If any exception occurs other than sql, it will throw here
                throw new OnlineShoppingException(exception.Message);
            }
            // The finally block executes whether exception rise or not and whether exception handled or not
            finally
            {
                //closing the connection
                con.Close();
            }
            return productsList;
        }

        /// <summary>
        /// This method retrieves the complete details of the product based on the id 
        /// </summary>
        /// <param name="productId">procuct id is passed</param>
        /// <returns>Returns single product based on id</returns>
        public ProductDetails GetDetailsOfProductByProductId(int productId)
        {
            // creates object of type list for ProductDetails entity class
            ProductDetails productDetails = new ProductDetails();
            //try block incase if code throws an exception
            try
            {
                //configuring command for SELECT statement
                cmd = new SqlCommand();
                //Query for selecting the product by productid from ol_product table in database
                cmd.CommandText = "select * from ol_product where pid=@id";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@id", productId);
                //specify the type of command
                cmd.CommandType = CommandType.Text;
                //attach connection to the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //read the records from data reader and add them to the collection
                SqlDataReader sdr = cmd.ExecuteReader();
                //Executes the command
                while (sdr.Read())
                {
                    productDetails.Pid = (int)sdr[0];
                    productDetails.ProductName = sdr[2].ToString();
                    productDetails.Picture = sdr[3].ToString();                    
                    productDetails.Price = (int)sdr[4];                    
                    productDetails.Content = sdr[5].ToString();
                }
                //close sdr connection
                sdr.Close();
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException sqlException)
            {
                //if sql exception occurs , it will be thrown
                throw new OnlineShoppingException(sqlException.Message);
            }
            //If any other exception occurs other than sqlexception,here they will be handled
            catch (Exception exception)
            {
                //If any exception occurs other than sql, it will throw here
                throw new OnlineShoppingException(exception.Message);
            }
            // The finally block executes whether exception rise or not and whether exception handled or not
            finally
            {
                //closing the connection
                con.Close();
            }
            return productDetails;
        }

        /// <summary>
        /// This method will add the products to the cart when clicked on add to cart button
        /// and returns to the home page
        /// </summary>
        /// <param name="cartItem">cartitems list is passed</param>
        public void AddToCart(List<CartItems> cartItems)
        {
            
            //Declaring variable to know how many products was added to cart
            int itemsEffected;
            //try block incase if code throws an exception
            try
            {
                //Open the connection
                con.Open();
                //This method stores list of cartItems into another variable items
                foreach (var items in cartItems)
                {
                    //Configuring command for INSERT statement
                    cmd = new SqlCommand();
                    //Query for INSERTing products to ol_cart table in database
                    cmd.CommandText = "insert into ol_cart values(@pid,@pname,@picture,@price,@qty)";
                    //supply values to the parameters of the command
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@pid", items.Pid);
                    cmd.Parameters.AddWithValue("@pname", items.ProductName);
                    cmd.Parameters.AddWithValue("@picture", items.Picture);                    
                    cmd.Parameters.AddWithValue("@price", items.Price);
                    cmd.Parameters.AddWithValue("@qty", items.Quantity);
                    //specify the type of command
                    cmd.CommandType = System.Data.CommandType.Text;
                    //Attaching connection to command
                    cmd.Connection = con;
                    //It gives the number of products added
                    itemsEffected = cmd.ExecuteNonQuery();
                    //Checking the condition
                    if (itemsEffected == 0)
                    {
                        throw new Exception("Your cart is empty");
                    }
                }
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException sqlException)
            {
                //if sql exception occurs , it will be thrown
                throw new OnlineShoppingException(sqlException.Message);
            }
            //If any other exception occurs other than sqlexception,here they will be handled
            catch (Exception exception)
            {
                //If any exception occurs other than sql, it will throw here
                throw new OnlineShoppingException(exception.Message);
            }
            // The finally block executes whether exception rise or not and whether exception handled or not
            finally
            {
                //closing the connection
                con.Close();
            }
        }

        /// <summary>
        /// This method displays all the details of products present in the cart when clicked 
        /// on cart item in home page
        /// </summary>
        /// <returns>returns added cart items</returns>
        public List<CartItems> GetCartDetails()
        {
            // creates object of type list for Products entity class
            List<CartItems> listCart = new List<CartItems>();
            //try block incase if code throws an exception
            try
            {
                //Configuring command for SELECT statement
                cmd = new SqlCommand();
                //Query for SELECTing from ol_cart table 
                cmd.CommandText = "select * from ol_cart";
                cmd.Parameters.Clear();
                //Specify the type of command
                cmd.CommandType = CommandType.Text;
                //Attach the connection to command
                cmd.Connection = con;
                //Open the connection
                con.Open();
                //Executes the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    CartItems cartItems = new CartItems
                    {
                        Pid = (int)sdr[0],
                        ProductName = sdr[1].ToString(),
                        Picture = sdr[2].ToString(),                        
                        Price = (int)sdr[4],
                        Quantity = (int)sdr[3]
                    };
                    listCart.Add(cartItems);
                }
                //Close the sdr connection
                sdr.Close();
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException sqlException)
            {
                //if sql exception occurs , it will be thrown
                throw new OnlineShoppingException(sqlException.Message);
            }
            //If any other exception occurs other than sqlexception,here they will be handled
            catch (Exception exception)
            {
                //If any exception occurs other than sql, it will throw here
                throw new OnlineShoppingException(exception.Message);
            }
            // The finally block executes whether exception rise or not and whether exception handled or not
            finally
            {
                //closing the connection
                con.Close();
            }
            //returns the details of cart
            return listCart;
        }                     

        /// <summary>
        /// This method adds the cart items to the ddatabase 
        /// </summary>
        /// <param name="cartItems"></param>
        public void PostToCart(CartItems cartItems)
        {
            //Declaring variable to know how many products was added to database           
            int itemsEffected;
            //try block incase if code throws an exception
            try
            {
                //Configuring command for INSERT statement
                cmd = new SqlCommand();
                //Query for INSERT statement for posting to cart before placing order
                cmd.CommandText = "insert into ol_cart values(@pid,@pname,@picture,@price,@qty)";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@pid", cartItems.Pid);
                cmd.Parameters.AddWithValue("@pname", cartItems.ProductName);
                cmd.Parameters.AddWithValue("@picture", cartItems.Picture);
               
                cmd.Parameters.AddWithValue("@price", cartItems.Price);
                cmd.Parameters.AddWithValue("@qty", cartItems.Quantity);
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection
                cmd.Connection = con;
                 //OPen the connection
                con.Open();
                //It gives the number of products added
                itemsEffected = cmd.ExecuteNonQuery();                
                //Checking the condition
                if (itemsEffected == 0)
                {
                    throw new Exception("Item cannot be added to cart");
                }
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException sqlException)
            {
                //if sql exception occurs , it will be thrown
                throw new OnlineShoppingException(sqlException.Message);
            }
            //If any other exception occurs other than sqlexception,here they will be handled
            catch (Exception exception)
            {
                //If any exception occurs other than sql, it will throw here
                throw new OnlineShoppingException(exception.Message);
            }
            // The finally block executes whether exception rise or not and whether exception handled or not
            finally
            {
                //closing the connection
                con.Close();
            }
        }

        /// <summary>
        /// This method will cancel the order that are previously buyed by the user
        /// </summary>
        /// <param name="productId">Product Id is passed as an parameter</param>        
        public void DeleteItemFromCart(int productId)
        {
            //variable to store the count of total products deleted
            int recordsAffected;
            //try block incase if code throws an exception
            try
            {
                //Configuring command for SELECT statement
                cmd = new SqlCommand();
                //Query for DELETE the products from ol_Cart
                cmd.CommandText = "delete from ol_cart where pid=@id";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@id", productId);
                //Specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection
                cmd.Connection = con;
                //Open the connection
                con.Open();
                //The deleted products count is stored 
                recordsAffected = cmd.ExecuteNonQuery();
                //checking the condition                
                if (recordsAffected == 0)
                {
                    throw new Exception("Could not delete");
                }
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException sqlException)
            {
                //if sql exception occurs , it will be thrown
                throw new OnlineShoppingException(sqlException.Message);
            }
            //If any other exception occurs other than sqlexception,here they will be handled
            catch (Exception exception)
            {
                //If any exception occurs other than sql, it will throw here
                throw new OnlineShoppingException(exception.Message);
            }
            // The finally block executes whether exception rise or not and whether exception handled or not
            finally
            {
                //closing the connection
                con.Close();
            }
        }

        /// <summary>
        /// This method will retrieve the user name that is stored in the database
        /// </summary>
        /// <param name="userName">User name is passed as parameter</param>
        /// <returns>Returns the user name</returns>
        public LoginDetails GetUserName(string userName)
        {
            LoginDetails l = new LoginDetails();
            //try block incase if code throws an exception
            try
            {               
                //Configuring command for SELECT statement
                cmd = new SqlCommand();
                //Query for selecting details from ol_login table in details
                cmd.CommandText = "select * from ol_login where username=@un";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@un", userName);
                //Specify the type of command
                cmd.CommandType = CommandType.Text;
                //Attaching the connection
                cmd.Connection = con;
                //Open the connection
                con.Open();
                //read the records from data reader and add them to the collection
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    l.UserName = sdr[0].ToString();
                    l.Password = sdr[1].ToString();                    
                }
                //Close the sdr Connection
                sdr.Close();
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException sqlException)
            {
                //if sql exception occurs , it will be thrown
                throw new OnlineShoppingException(sqlException.Message);
            }
            //If any other exception occurs other than sqlexception,here they will be handled
            catch (Exception exception)
            {
                //If any exception occurs other than sql, it will throw here
                throw new OnlineShoppingException(exception.Message);
            }
            // The finally block executes whether exception rise or not and whether exception handled or not
            finally
            {
                //closing the connection
                con.Close();
            }            
            return l;
        }

        /// <summary>
        /// This method will retrieve the password that is stored in the database
        /// </summary>
        /// <param name="password">password is passed as an parameter</param>
        /// <returns>Returns the password that is stored in the database</returns>
        public LoginDetails GetPassword(string password)
        {
            //Creating instance for logindetails class
            LoginDetails l = new LoginDetails();
            //try block incase if code throws an exception
            try
            {
                //Configuring command for SELECT statement
                cmd = new SqlCommand();
                //Query for selecting the password from ol_login table from database
                cmd.CommandText = "select password from ol_login where password=@pwd";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@pwd", password);
                //Specify the type of command
                cmd.CommandType = CommandType.Text;
                //Attaching the connection
                cmd.Connection = con;
                //Open the connection
                con.Open();
                //read the records from data reader and add them to the collection
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    l.Password = sdr[0].ToString();
                }
                //close the sdr connection
                sdr.Close();
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException sqlException)
            {
                //if sql exception occurs , it will be thrown
                throw new OnlineShoppingException(sqlException.Message);
            }
            //If any other exception occurs other than sqlexception,here they will be handled
            catch (Exception exception)
            {
                //If any exception occurs other than sql, it will throw here
                throw new OnlineShoppingException(exception.Message);
            }
            // The finally block executes whether exception rise or not and whether exception handled or not
            finally
            {
                //closing the connection
                con.Close();
            }
            return l;
        }        
    }
}
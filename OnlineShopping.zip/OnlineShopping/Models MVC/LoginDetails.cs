﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;//for validations

namespace OnlineShoppingMvc.Models
{
    /// <summary>
    /// Login Details Class
    /// </summary>
    public class LoginDetails
    {
        [Required(ErrorMessage="User name Should not be empty")]
        [StringLength(30,MinimumLength =4,ErrorMessage ="Name of the user must be in between 4 to 30 characters")]
        /// <summary>
        /// User Name (name of the user)
        /// </summary>
        public string UserName { get; set; }

           
        [Required(ErrorMessage = "Password Should not be empty")]
        [StringLength(10, MinimumLength = 8, ErrorMessage = "Password should be in between 8-10 letters")]
        /// <summary>
        /// Password( Password set by user)
        /// </summary>
        public string Password { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net.Http;
using System.Web.Http;
using OnlineShoppingMvc.Models; //for online shopping models in mvc
using Newtonsoft.Json;
using System.Web.Security;
namespace OnlineShoppingMvc.Controllers
{
    public class AuthorizationController : Controller
    {

        /// <summary>
        /// This method will display the login page where the details of user was passed before placing the order
        /// </summary>
        /// <param name="login"></param>
        /// <returns>Returns to Successful(Place Order) when details are correct</returns>
        /// // GET: Authorization
        [HttpGet]
        public ActionResult Login()
        {
            var returnUrl = Request.QueryString.Get("ReturnUrl");
            ViewData.Add("returnUrl", returnUrl);
            return View();
        }
        [HttpPost]
        public ActionResult Login(LoginDetails login)
        {
            //localhost connection of API
            Uri uri = new Uri("http://localhost:56805/api/");
            //call API for get
            using (var client = new HttpClient())
            {
                //sets the base address that defines the uri path
                client.BaseAddress = uri;
                //Sends a Get Request to the Specified Uri
                var uname = client.GetStringAsync("Authorization/GetUserName/" + login.UserName).Result;
                //gets the user name entered by the user 
                var name = JsonConvert.DeserializeObject<LoginDetails>(uname);
                //storing the user name
                string userName = name.UserName;

                //Sends a Get Request to the Specified Uri
                var p = client.GetStringAsync("Authorization/GetPassword/" + login.Password).Result;
                //gets the password entered by the user
                var pwd = JsonConvert.DeserializeObject<LoginDetails>(p);
                //storing the passwowrd
                string password = pwd.Password;

                //checks the user name and password entered by the user with the details stored in database
                if ((login.UserName.Equals(userName)) && (login.Password.Equals(password)))
                {
                    FormsAuthentication.SetAuthCookie(login.UserName, false);
                    var returnUrl = Request.Form["returnUrl"];
                    return Redirect(returnUrl);
                }
                //If the details was not matched then it will prints the error message
                else
                {
                    ModelState.AddModelError("UserName", "UserName,Password and email are invalid,Please try again");
                }
                var returnUrl1 = Request.QueryString.Get("ReturnUrl");
                ViewData.Add("returnUrl", returnUrl1);
                return View();
            }
        }

        /// <summary>
        /// After successful in placing order the user can logout from the site
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return View();
        }
    }
}

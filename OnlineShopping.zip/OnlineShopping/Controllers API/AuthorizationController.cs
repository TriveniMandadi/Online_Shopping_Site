﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OnlineShoppingEntityLib;  // For entities in OnlineShoppingEntityLib
using OnlineShoppingBusinessLayerLib;//For OnlineShoppingBusinessLib
using OnlineShoppingExceptionLib;   //For user defined exception library

namespace OnlineShoppingAPI.Controllers
{
    /// <summary>
    /// Authorization Controller for web API
    /// </summary>
    public class AuthorizationController : ApiController
    {
        /// <summary>
        /// This method will retrieve the user name that is stored in the database
        /// </summary>
        /// <param name="userName">User name is passed as parameter</param>
        /// <returns>Returns the user name</returns>
        //setting up the route
        [Route("api/Authorization/GetUserName/{userName}")]                
        public HttpResponseMessage GetUserName(string userName)
        {
            //HttpResponseMessage works with HTTP protocol to return the data with status/error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "User found");
            //try block incase if code throws an exception
            try
            {
                //creates object for business layer
                OlShoppingBusinessLayer bll = new OlShoppingBusinessLayer();
                //details is stored in a variable
                var uname = bll.GetUserName(userName);
                //creates the response and returns the details of product
                httpResponseMessage = Request.CreateResponse<LoginDetails>(uname);

            }
            catch (OnlineShoppingException e)
            {
                //if the product does not exist it will return the status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, e.Message);
            }
            //If any other exceptions that are not handled in previous catch block, it will be handled here
            catch (Exception e)
            {
                //if the product does not exist it will return the status 
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, e.Message);
            }
            //returns httpResponse message
            return httpResponseMessage;
        }

        [Route("api/Authorization/GetPassword/{password}")]        
        public HttpResponseMessage GetPassword(string password)
        {
            //HttpResponseMessage works with HTTP protocol to return the data with status/error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Password");
            //try block incase if code throws an exception
            try
            {
                //creates object for business layer
                OlShoppingBusinessLayer bll = new OlShoppingBusinessLayer();
                //details is stored in a variable
                var pwd = bll.GetPassword(password);
                //creates the response and returns the details of product
                httpResponseMessage = Request.CreateResponse<LoginDetails>(pwd);
            }
            catch (OnlineShoppingException e)
            {
                //if the product does not exist it will return the status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, e.Message);
            }
            //If any other exceptions that are not handled in previous catch block, it will be handled here
            catch (Exception e)
            {
                //if the product does not exist it will return the status 
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, e.Message);
            }
            //returns httpResponse message
            return httpResponseMessage;
        }

    }
}
